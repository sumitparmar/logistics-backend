const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema(
  {
    // -------------------
    // CORE REFERENCES
    // -------------------
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    borzoOrderId: {
      type: String,
      required: true,
      index: true,
    },

    // -------------------
    // CUSTOMER
    // -------------------
    customer: {
      name: { type: String, required: true },
      phone: { type: String, required: true },
    },

    // -------------------
    // LEGACY SINGLE PICKUP/DROP (KEEP)
    // -------------------
    pickup: {
      address: { type: String, required: true },
      lat: Number,
      lng: Number,
    },

    drop: {
      address: { type: String, required: true },
      lat: Number,
      lng: Number,
    },

    // -------------------
    // NEW MULTI-STOP STRUCTURE
    // -------------------
    stops: [
      {
        type: {
          type: String,
          enum: ["PICKUP", "DROP"],
          required: true,
        },
        address: { type: String, required: true },
        lat: Number,
        lng: Number,

        building: String,
        floor: String,
        unit: String,
        instructions: String,

        name: String,
        phone: String,
      },
    ],

    // -------------------
    // DELIVERY CONFIG
    // -------------------
    deliveryType: {
      type: String,
      enum: ["NOW", "EOD", "SCHEDULED"],
      default: "NOW",
    },

    vehicleTypeId: {
      type: Number,
      index: true,
    },

    // -------------------
    // PACKAGE DETAILS
    // -------------------
    package: {
      weight: Number,
      category: String,
      description: String,
      declaredValue: Number,
    },

    // -------------------
    // PAYMENT DETAILS
    // -------------------
    payment: {
      method: {
        type: String,
        enum: ["CASH", "CARD", "WALLET"],
        default: "CASH",
      },
      feePayer: {
        type: String,
        enum: ["PICKUP", "DROP"],
        default: "DROP",
      },
    },

    // -------------------
    // VEHICLE (PROVIDER RESPONSE)
    // -------------------
    vehicle: {
      type: {
        type: String,
        index: true,
      },
    },

    // -------------------
    // COURIER INFO
    // -------------------
    courier: {
      courierId: Number,
      name: String,
      surname: String,
      phone: String,
      photoUrl: String,

      location: {
        lat: Number,
        lng: Number,
      },
    },

    // -------------------
    // DELIVERY STATUS
    // -------------------
    delivery: {
      deliveryId: Number,
      status: String,
      statusDescription: String,
      statusDatetime: Date,
      trackingUrl: String,
    },

    // -------------------
    // PRICING
    // -------------------
    pricing: {
      amount: { type: Number, required: true },
      currency: { type: String, required: true },
    },

    declaredValue: {
      type: Number,
      default: null,
    },

    cod: {
      enabled: {
        type: Boolean,
        default: false,
      },
      amount: {
        type: Number,
        default: 0,
      },
    },

    // -------------------
    // ORDER STATUS
    // -------------------
    status: {
      type: String,
      enum: [
        "CREATED",
        "ASSIGNED",
        "PICKED_UP",
        "IN_TRANSIT",
        "DELIVERED",
        "CANCELLED",
        "FAILED",
      ],
      default: "CREATED",
    },

    statusHistory: [
      {
        status: {
          type: String,
          enum: [
            "CREATED",
            "ASSIGNED",
            "PICKED_UP",
            "IN_TRANSIT",
            "DELIVERED",
            "CANCELLED",
            "FAILED",
          ],
          required: true,
        },
        timestamp: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    // -------------------
    // PROVIDER
    // -------------------
    provider: {
      type: String,
      default: "BORZO",
      index: true,
    },

    rawProviderResponse: {
      type: Object,
      required: true,
    },

    codSettled: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
);

orderSchema.index({ borzoOrderId: 1, provider: 1 }, { unique: true });
orderSchema.index({ user: 1 });

module.exports = mongoose.model("Order", orderSchema);
